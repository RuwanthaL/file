<?php
namespace App\Http\Controllers\Admin;
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use App\Models\form_basic;
use Brian2694\Toastr\Facades\Toastr;

class FormController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$data = DB::table('form_basic')->get();
        $data = form_basic::all();
        return view('form',compact("data"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveRecord(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|numeric',
            'gander' => 'required|in:male,female',
            'email' => 'required|email',
            'upload' => 'required|max:1024'
        ]);
DB::beginTransaction();
try {
    //upload file
    $file = $request->file('upload')->store('files');

    $form = new form_basic;
    $form->name = $request->name;
    $form->age = $request->age;
    $form->gander = $request->gander;
    $form->email = $request->email;
    $form->upload = $file;
    $form->save();

    DB::commit();
    //Toastr::success('create new holiday successfully return redirect()->back();
    return redirect()->back;

}
catch(\Exception $e){
    DB::rollback();
    //Toastr::error('Add Holiday fail :)','Error');
    return redirect()->back();

}
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function download($id)
    {
        $data=DB::table('form_basics')->where('id',$id)->first();
        $filepath = storage_path("app/{$data->upload}");
        return \Response::download($filepath);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
